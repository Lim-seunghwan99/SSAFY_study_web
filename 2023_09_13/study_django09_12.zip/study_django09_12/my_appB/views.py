from django.shortcuts import render
from django.shortcuts import HttpResponse

# Create your views here.
def hello2(request):
    return render(request, 'my_appB/index2.html')

def greet(request):
    return render(request, 'my_appB/greet.html')