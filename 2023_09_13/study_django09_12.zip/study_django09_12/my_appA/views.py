from django.shortcuts import render
from django.shortcuts import HttpResponse
# Create your views here.
def hello1(request):
    # return HttpResponse("<h1>안녕하세요1111</h1>")
    return render(request, 'my_appA/index.html')